﻿Information regarding changes from 2.0.7 to 3.0 are in the changelog.txt file.




- Contact Information

website: http://frumph.net
twitter: http://www.twitter.com/Frumph
email: philip@frumph.net
forums: http://forum.frumph.net


